*PADS-LIBRARY-PART-TYPES-V9*

TLE4275D TLE4275D I ANA 9 1 0 0 0
TIMESTAMP 2026.06.10.13.51.29
"Manufacturer_Name" Infineon
"Manufacturer_Part_Number" TLE4275D
"Mouser Part Number" 726-TLE4275D
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Infineon-Technologies/TLE4275D?qs=3D22qUCSisCm%252B2ao74XBfA%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" LDO Voltage Regulators LW Drop Fixed VOLT REGULATOR 200mA 5V
"Datasheet Link" https://www.infineon.com/dgdl/Infineon-TLE4275V50-DS-v01_07-en%5B1%5D.pdf?fileId=db3a304412b407950112b437f96169d5
"Geometry.Height" 2.5mm
GATE 1 5 0
TLE4275D
1 0 U I
2 0 U RO
3 0 U GND
4 0 U D
5 0 U Q

*END*
*REMARK* SamacSys ECAD Model
15915530/362809/2.50/5/3/Integrated Circuit
